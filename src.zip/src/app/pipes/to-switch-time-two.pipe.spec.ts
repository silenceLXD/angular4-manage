import { ToSwitchTimeTwoPipe } from './to-switch-time-two.pipe';

describe('ToSwitchTimeTwoPipe', () => {
  it('create an instance', () => {
    const pipe = new ToSwitchTimeTwoPipe();
    expect(pipe).toBeTruthy();
  });
});
