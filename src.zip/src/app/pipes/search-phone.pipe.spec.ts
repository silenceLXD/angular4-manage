import { SearchPhonePipe } from './search-phone.pipe';

describe('SearchPhonePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchPhonePipe();
    expect(pipe).toBeTruthy();
  });
});
