import { GetNumMonthPipe } from './get-num-month.pipe';

describe('GetNumMonthPipe', () => {
  it('create an instance', () => {
    const pipe = new GetNumMonthPipe();
    expect(pipe).toBeTruthy();
  });
});
