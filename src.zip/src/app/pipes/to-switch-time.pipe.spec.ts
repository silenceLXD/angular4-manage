import { ToSwitchTimePipe } from './to-switch-time.pipe';

describe('ToSwitchTimePipe', () => {
  it('create an instance', () => {
    const pipe = new ToSwitchTimePipe();
    expect(pipe).toBeTruthy();
  });
});
