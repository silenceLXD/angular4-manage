import { GetLongTimesPipe } from './get-long-times.pipe';

describe('GetLongTimesPipe', () => {
  it('create an instance', () => {
    const pipe = new GetLongTimesPipe();
    expect(pipe).toBeTruthy();
  });
});
