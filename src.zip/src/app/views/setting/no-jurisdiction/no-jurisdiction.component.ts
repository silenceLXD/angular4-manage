import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-jurisdiction',
  templateUrl: './no-jurisdiction.component.html',
  styleUrls: ['./no-jurisdiction.component.css']
})
export class NoJurisdictionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
