import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-realroom',
  templateUrl: './user-realroom.component.html',
  styleUrls: ['./user-realroom.component.css']
})
export class UserRealroomComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
