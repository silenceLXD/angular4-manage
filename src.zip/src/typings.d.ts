/* SystemJS module definition */
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
declare var $: any;
declare var jQuery: any;
declare var ckplayer: any;
declare var EventSource: any;
declare var Strophe: any;
declare var $pres: any;
declare var $msg: any;
declare var Strophe: any;
declare var WxLogin: any;
