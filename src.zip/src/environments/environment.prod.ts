export const environment = {
  production: true,
  apiBase: '/'
};
